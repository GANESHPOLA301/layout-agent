import { useState, useRef, useEffect } from "react";

const INITIAL_JSON = {
  rootNodes: ["artboard_1778485662755_3"],
  imageUrl:
    "https://res.cloudinary.com/dzydbgyfj/image/upload/v1778502510/Instagram_Post_1080x1080_19_iw9uqy.png",
  nodes: {
    img_1778485681535_4: {
      x: -2.480199702295863,
      y: 0,
      id: "img_1778485681535_4",
      nh: 1,
      nw: 1,
      nx: -0.0022964812058295027,
      ny: 0,
      data: {
        fit: "cover",
        assetId: "asset_1778485681534_jl4fd6",
        sourceUrl:
          "https://res.cloudinary.com/dzydbgyfj/image/upload/v1778485682/qgi9ecexyirh7vbvij9k.png",
      },
      name: "Background.png",
      type: "image",
      style: { layout: {}, visual: { borderRadius: 0 } },
      width: 1080,
      height: 1080,
      parentId: "artboard_1778485662755_3",
    },
    img_1778486846247_10: {
      x: 333.4017235189475,
      y: 124.94234803158162,
      id: "img_1778486846247_10",
      nh: 0.037741738009449737,
      nw: 0.034185517608088176,
      nx: 0.30870529955458104,
      ny: 0.11568735928850149,
      data: {
        fit: "cover",
        assetId: "asset_1778486846244_9hw86o",
        sourceUrl:
          "https://res.cloudinary.com/dzydbgyfj/image/upload/v1778486847/c2pgksvxa3ec61bchter.png",
      },
      name: "Vector (2).png",
      type: "image",
      style: { layout: {}, visual: { borderRadius: 0 } },
      width: 36.920359016735226,
      height: 40.761077050205714,
      parentId: "artboard_1778485662755_3",
    },
    img_1778486856821_11: {
      x: 229.76161365259213,
      y: 126.70185327118239,
      id: "img_1778486856821_11",
      nh: 0.03774173800944972,
      nw: 0.034185517608088176,
      nx: 0.21274223486351124,
      ny: 0.11731653080665036,
      data: {
        fit: "cover",
        assetId: "asset_1778486856821_s8v1en",
        sourceUrl:
          "https://res.cloudinary.com/dzydbgyfj/image/upload/v1778486857/ksyoela4vnvrtlt49lf1.png",
      },
      name: "Vector (1).png",
      type: "image",
      style: { layout: {}, visual: { borderRadius: 0 } },
      width: 36.920359016735226,
      height: 40.7610770502057,
      parentId: "artboard_1778485662755_3",
    },
    img_1778487081392_12: {
      x: 283.7974713072252,
      y: 127.86270704831685,
      id: "img_1778487081392_12",
      nh: 0.03503770188284304,
      nw: 0.03418551760808818,
      nx: 0.2627754363955789,
      ny: 0.1183913954151082,
      data: {
        fit: "cover",
        assetId: "asset_1778487081391_spprg9",
        sourceUrl:
          "https://res.cloudinary.com/dzydbgyfj/image/upload/v1778487081/y6sbozdszgf0hc9wjmev.png",
      },
      name: "Vector (1).png",
      type: "image",
      style: { layout: {}, visual: { borderRadius: 0 } },
      width: 36.92035901673524,
      height: 37.84071803347048,
      parentId: "artboard_1778485662755_3",
    },
    img_1778487101466_13: {
      x: 432.5602419818531,
      y: 126.70185327118239,
      id: "img_1778487101466_13",
      nh: 0.03233366575623633,
      nw: 0.039593589861301584,
      nx: 0.4005187425757899,
      ny: 0.11731653080665036,
      data: {
        fit: "cover",
        assetId: "asset_1778487101465_wnrgke",
        sourceUrl:
          "https://res.cloudinary.com/dzydbgyfj/image/upload/v1778487101/oe2lgnfgtpl63vffqvuc.png",
      },
      name: "Vector (1).png",
      type: "image",
      style: { layout: {}, visual: { borderRadius: 0 } },
      width: 42.761077050205714,
      height: 34.92035901673523,
      parentId: "artboard_1778485662755_3",
    },
    img_1778487110538_14: {
      x: 380.54333909425605,
      y: 127.86270704831685,
      id: "img_1778487110538_14",
      nh: 0.03233366575623633,
      nw: 0.03688955373469488,
      nx: 0.35235494360579267,
      ny: 0.1183913954151082,
      data: {
        fit: "cover",
        assetId: "asset_1778487110536_5gy5sx",
        sourceUrl:
          "https://res.cloudinary.com/dzydbgyfj/image/upload/v1778487110/nxe2gyhmho4ncbhjpb08.png",
      },
      name: "Vector (2).png",
      type: "image",
      style: { layout: {}, visual: { borderRadius: 0 } },
      width: 39.84071803347047,
      height: 34.92035901673523,
      parentId: "artboard_1778485662755_3",
    },
    img_1778489515746_17: {
      x: 89.82235511988935,
      y: 571.8382567085082,
      id: "img_1778489515746_17",
      nh: 0.3152992662905912,
      nw: 0.7637522830873364,
      nx: 0.08316884733323088,
      ny: 0.5294798673226928,
      data: {
        fit: "cover",
        assetId: "asset_1778489515744_q47n31",
        sourceUrl:
          "https://res.cloudinary.com/dzydbgyfj/image/upload/v1778489518/mfkzgbakd77adfnbbcsv.png",
      },
      name: "Product.png",
      type: "image",
      style: { layout: {}, visual: { borderRadius: 0 } },
      width: 824.8524657343233,
      height: 340.5232075938385,
      parentId: "artboard_1778485662755_3",
    },
    text_1778486004640_6: {
      x: 346.02118499384466,
      y: 956.9792790379693,
      id: "text_1778486004640_6",
      nh: 0.06804963433919406,
      nw: 0.45466173716839364,
      nx: 0.3203899861054117,
      ny: 0.8860919250351568,
      data: { content: "Limited time offer" },
      name: "Text",
      type: "text",
      style: {
        layout: {},
        visual: {
          fill: { type: "none" },
          color: { type: "solid", value: "#FFFF" },
          fontSize: 48,
          fontFamily: "Arial",
          fontWeight: 600,
        },
      },
      width: 491.03467614186513,
      height: 73.49360508632958,
      parentId: "artboard_1778485662755_3",
      fontSizeRatio: 0.044444444444444446,
    },
    text_1778486136643_7: {
      x: 194.38702539993648,
      y: 350.16045634860865,
      id: "text_1778486136643_7",
      nh: 0.037037037037037035,
      nw: 0.7120318482825286,
      nx: 0.17998798648142267,
      ny: 0.32422264476723023,
      data: { content: "Comfort that defines modern living." },
      name: "Text",
      type: "text",
      style: {
        layout: {},
        visual: {
          fill: { type: "none" },
          color: { type: "solid", value: "#FFFF" },
          fontSize: 48,
          fontFamily: "Arial",
          fontWeight: 600,
        },
      },
      width: 768.994396145131,
      height: 40,
      parentId: "artboard_1778485662755_3",
      fontSizeRatio: 0.044444444444444446,
    },
    text_1778486306230_8: {
      x: 133.38976610032938,
      y: 175.51991211747026,
      id: "text_1778486306230_8",
      nh: 0.3503396592170152,
      nw: 0.7815649104172034,
      nx: 0.12350904268549016,
      ny: 0.1625184371458058,
      data: { content: "      Luxury Comfort,     \n  Surprisingly Attainable" },
      name: "Text",
      type: "text",
      style: {
        layout: {},
        visual: {
          fill: { type: "none" },
          color: { type: "solid", value: "#FFFF" },
          fontSize: 72,
          fontStyle: "italic",
          fontFamily: "Arial",
          fontWeight: 700,
        },
      },
      width: 844.0901032505798,
      height: 378.36683195437644,
      parentId: "artboard_1778485662755_3",
      fontSizeRatio: 0.06666666666666667,
    },
    text_1778486552508_9: {
      x: 482.7000303705086,
      y: 121.09848637690123,
      id: "text_1778486552508_9",
      nh: 0.04541430724262293,
      nw: 0.43652086535182927,
      nx: 0.44694447256528574,
      ny: 0.1121282281267604,
      data: { content: "Over 8,000 happy homes" },
      name: "Text",
      type: "text",
      style: {
        layout: {},
        visual: {
          fill: { type: "none" },
          color: { type: "solid", value: "#FFFF" },
          fontSize: 40,
          fontFamily: "Arial",
          fontWeight: 600,
        },
      },
      width: 471.4425345799756,
      height: 49.04745182203276,
      parentId: "artboard_1778485662755_3",
      fontSizeRatio: 0.037037037037037035,
    },
    text_1778489078397_16: {
      x: 130.87523314340268,
      y: 448.5125264397059,
      id: "text_1778489078397_16",
      nh: 0.13998918694820744,
      nw: 0.16302282390535613,
      nx: 0.12118077142907656,
      ny: 0.415289376333061,
      data: { content: "20%\nOFF" },
      name: "Text",
      type: "text",
      style: {
        layout: {},
        visual: {
          fill: { type: "none" },
          color: { type: "solid", value: "#FFFF" },
          fontSize: 56,
          fontFamily: "Arial",
          fontWeight: 700,
        },
      },
      width: 176.0646498177846,
      height: 151.18832190406403,
      parentId: "artboard_1778485662755_3",
      fontSizeRatio: 0.05185185185185185,
    },
    circle_1778488914968_15: {
      x: 103.6984883092603,
      y: 437.4183771828574,
      id: "circle_1778488914968_15",
      nh: 0.14248292500533227,
      nw: 0.14789099725854568,
      nx: 0.09601711880487064,
      ny: 0.4050170159100531,
      data: { shapeType: "circle" },
      name: "Circle",
      type: "shape",
      style: {
        layout: {},
        visual: {
          fill: { type: "solid", value: "#F4CF1B" },
          stroke: { type: "solid", value: "#F4CF1B" },
          strokeWidth: 2,
        },
      },
      width: 159.72227703922934,
      height: 153.88155900575885,
      parentId: "artboard_1778485662755_3",
    },
    artboard_1778485662755_3: {
      x: -479.700399885017,
      y: -724.4991007769831,
      id: "artboard_1778485662755_3",
      data: {
        preset: "instagram-post",
        showLabel: true,
        backgroundColor: "#ffffff",
      },
      name: "Instagram Post",
      type: "artboard",
      style: { layout: {}, visual: {} },
      width: 1080,
      height: 1080,
      children: [
        "img_1778485681535_4",
        "text_1778486004640_6",
        "text_1778486136643_7",
        "text_1778486306230_8",
        "text_1778486552508_9",
        "img_1778486846247_10",
        "img_1778486856821_11",
        "img_1778487081392_12",
        "img_1778487101466_13",
        "img_1778487110538_14",
        "circle_1778488914968_15",
        "text_1778489078397_16",
        "img_1778489515746_17",
      ],
    },
  },
};

const SYSTEM_PROMPT = `You are a layout agent for a design tool. You receive a design JSON and a user instruction, then return an updated JSON.

The JSON has a "nodes" object where each node can be:
- type "artboard": the canvas (has width, height, children array)
- type "image": positioned image with x, y, width, height, nx (normalized x = x/artboardW), ny (normalized y = y/artboardH), nw (normalized width), nh (normalized height)
- type "text": text node with x, y, width, height, data.content, style.visual.fontSize, fontSizeRatio
- type "shape": shape like circle with x, y, width, height

Semantic roles (inferred by name/content):
- "Background.png" → background image (img_1778485681535_4)
- "Product.png" → product image (img_1778489515746_17)  
- Headline text → "Luxury Comfort, Surprisingly Attainable" (text_1778486306230_8)
- Subheadline → "Comfort that defines modern living." (text_1778486136643_7)
- Social proof → "Over 8,000 happy homes" (text_1778486552508_9)
- Offer badge (circle + 20% OFF text) → circle_1778488914968_15 + text_1778489078397_16
- CTA/footer → "Limited time offer" (text_1778486004640_6)
- Star icons → img_1778486846247_10, img_1778486856821_11, img_1778487081392_12, img_1778487101466_13, img_1778487110538_14

IMPORTANT RULES:
1. When changing artboard aspect ratio (e.g. 9:16), update the artboard width/height and reposition ALL nodes proportionally. For 9:16: width=1080, height=1920.
2. Always keep nx = x/artboardWidth, ny = y/artboardHeight, nw = width/artboardWidth, nh = height/artboardHeight in sync.
3. When moving elements, update x, y and the corresponding nx, ny.
4. When resizing elements, update width, height and nw, nh. Also update fontSizeRatio if text.
5. "Keep product large" = increase product image size significantly (nw/nh by ~1.3x).
6. "Move headline to top" = set headline y to ~30-60px, update ny accordingly.
7. "Move offer badge higher" = decrease y of both circle and text by same amount.
8. "Make headline smaller" = reduce fontSize by ~25-30%, update fontSizeRatio.

CRITICAL: Respond ONLY with a valid JSON object. No markdown, no explanation, no backticks. Just the raw JSON.`;

// ─── Wireframe Preview ────────────────────────────────────────────────────────
function WireframePreview({ json }) {
  const artboard = json.nodes["artboard_1778485662755_3"];
  const AW = artboard.width;
  const AH = artboard.height;
  const PREVIEW_W = 320;
  const PREVIEW_H = (AH / AW) * PREVIEW_W;
  const scale = PREVIEW_W / AW;

  const nodeOrder = artboard.children || [];

  return (
    <div
      style={{
        width: PREVIEW_W,
        height: PREVIEW_H,
        position: "relative",
        background: artboard.data?.backgroundColor || "#fff",
        border: "1px solid #2a2a3e",
        borderRadius: 8,
        overflow: "hidden",
        flexShrink: 0,
      }}
    >
      {nodeOrder.map((id) => {
        const node = json.nodes[id];
        if (!node || node.type === "artboard") return null;
        const nx = node.x * scale;
        const ny = node.y * scale;
        const nw = node.width * scale;
        const nh = node.height * scale;

        if (node.type === "image") {
          const isBg = node.name === "Background.png";
          const isProduct = node.name === "Product.png";
          return (
            <div
              key={id}
              title={node.name}
              style={{
                position: "absolute",
                left: nx,
                top: ny,
                width: nw,
                height: nh,
                background: isBg
                  ? "linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)"
                  : isProduct
                  ? "rgba(255,255,255,0.15)"
                  : "rgba(255,255,255,0.1)",
                border: isProduct
                  ? "1px dashed rgba(255,255,255,0.4)"
                  : isBg
                  ? "none"
                  : "1px dashed rgba(255,255,255,0.2)",
                borderRadius: node.style?.visual?.borderRadius || 0,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: 8 * scale,
                color: "rgba(255,255,255,0.5)",
                overflow: "hidden",
              }}
            >
              {isProduct && (
                <span style={{ fontSize: 9, color: "rgba(255,255,255,0.6)" }}>
                  📦 Product
                </span>
              )}
            </div>
          );
        }

        if (node.type === "shape" && node.data?.shapeType === "circle") {
          const fill = node.style?.visual?.fill?.value || "#F4CF1B";
          return (
            <div
              key={id}
              title="Offer Badge"
              style={{
                position: "absolute",
                left: nx,
                top: ny,
                width: nw,
                height: nh,
                background: fill,
                borderRadius: "50%",
              }}
            />
          );
        }

        if (node.type === "text") {
          const fontSize = (node.style?.visual?.fontSize || 16) * scale;
          const color = node.style?.visual?.color?.value || "#fff";
          const fw = node.style?.visual?.fontWeight || 400;
          const isItalic = node.style?.visual?.fontStyle === "italic";
          const content = node.data?.content || "";
          return (
            <div
              key={id}
              title={content}
              style={{
                position: "absolute",
                left: nx,
                top: ny,
                width: nw,
                height: nh,
                fontSize: Math.max(fontSize, 5),
                color,
                fontWeight: fw,
                fontStyle: isItalic ? "italic" : "normal",
                fontFamily: "Georgia, serif",
                lineHeight: 1.2,
                overflow: "hidden",
                whiteSpace: "pre-wrap",
                display: "flex",
                alignItems: "flex-start",
                justifyContent: "center",
                textAlign: "center",
              }}
            >
              {content.slice(0, 80)}
            </div>
          );
        }
        return null;
      })}
    </div>
  );
}

// ─── Main App ─────────────────────────────────────────────────────────────────
export default function LayoutAgent() {
  const [layoutJson, setLayoutJson] = useState(INITIAL_JSON);
  const [messages, setMessages] = useState([
    {
      role: "assistant",
      content:
        "Hi! I'm your layout agent. I can transform this Instagram Post design for you. Try asking me:\n\n• \"Convert this design to 9:16\"\n• \"Keep the product large\"\n• \"Move the headline to the top\"\n• \"Move the offer badge higher\"\n• \"Make the headline smaller\"",
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState("preview");
  const [history, setHistory] = useState([INITIAL_JSON]);
  const [historyIdx, setHistoryIdx] = useState(0);
  const messagesEndRef = useRef(null);
  const textareaRef = useRef(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = async () => {
    if (!input.trim() || loading) return;
    const userMsg = input.trim();
    setInput("");
    setMessages((prev) => [...prev, { role: "user", content: userMsg }]);
    setLoading(true);

    try {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 4000,
          system: SYSTEM_PROMPT,
          messages: [
            {
              role: "user",
              content: `Current layout JSON:\n${JSON.stringify(layoutJson, null, 2)}\n\nInstruction: ${userMsg}`,
            },
          ],
        }),
      });

      const data = await response.json();
      const rawText = data.content?.map((b) => b.text || "").join("") || "";

      let newJson;
      try {
        const clean = rawText.replace(/```json\n?|```\n?/g, "").trim();
        newJson = JSON.parse(clean);
      } catch {
        throw new Error("Could not parse response as JSON");
      }

      setLayoutJson(newJson);
      const newHistory = history.slice(0, historyIdx + 1);
      newHistory.push(newJson);
      setHistory(newHistory);
      setHistoryIdx(newHistory.length - 1);

      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: `✅ Layout updated! I've applied: "${userMsg}". The preview and JSON have been updated.`,
          jsonSnapshot: newJson,
        },
      ]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: `❌ Error: ${err.message}. Please try again.`,
        },
      ]);
    }

    setLoading(false);
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const undo = () => {
    if (historyIdx > 0) {
      const idx = historyIdx - 1;
      setHistoryIdx(idx);
      setLayoutJson(history[idx]);
    }
  };

  const redo = () => {
    if (historyIdx < history.length - 1) {
      const idx = historyIdx + 1;
      setHistoryIdx(idx);
      setLayoutJson(history[idx]);
    }
  };

  const reset = () => {
    setLayoutJson(INITIAL_JSON);
    setHistory([INITIAL_JSON]);
    setHistoryIdx(0);
    setMessages([
      {
        role: "assistant",
        content: "Layout reset to original. What would you like to change?",
      },
    ]);
  };

  const copyJson = () => {
    navigator.clipboard.writeText(JSON.stringify(layoutJson, null, 2));
  };

  const artboard = layoutJson.nodes["artboard_1778485662755_3"];

  return (
    <div
      style={{
        fontFamily: "'DM Mono', 'Courier New', monospace",
        background: "#0a0a14",
        minHeight: "100vh",
        color: "#e0e0f0",
        display: "flex",
        flexDirection: "column",
      }}
    >
      {/* Header */}
      <div
        style={{
          padding: "12px 24px",
          borderBottom: "1px solid #1e1e32",
          display: "flex",
          alignItems: "center",
          gap: 12,
          background: "#0d0d1a",
        }}
      >
        <div
          style={{
            width: 28,
            height: 28,
            borderRadius: 6,
            background: "linear-gradient(135deg, #6366f1, #8b5cf6)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: 14,
          }}
        >
          ⚡
        </div>
        <span style={{ fontWeight: 700, fontSize: 15, letterSpacing: "0.05em", color: "#c4b5fd" }}>
          Layout Agent
        </span>
        <span
          style={{
            marginLeft: "auto",
            fontSize: 11,
            color: "#4a4a6a",
            background: "#13131f",
            padding: "3px 8px",
            borderRadius: 4,
            border: "1px solid #1e1e32",
          }}
        >
          {artboard.width}×{artboard.height}
        </span>
        <button
          onClick={undo}
          disabled={historyIdx === 0}
          style={{
            background: "none",
            border: "1px solid #1e1e32",
            color: historyIdx === 0 ? "#2a2a3e" : "#8080a0",
            padding: "4px 10px",
            borderRadius: 4,
            cursor: historyIdx === 0 ? "not-allowed" : "pointer",
            fontSize: 12,
          }}
        >
          ↩ Undo
        </button>
        <button
          onClick={redo}
          disabled={historyIdx === history.length - 1}
          style={{
            background: "none",
            border: "1px solid #1e1e32",
            color: historyIdx === history.length - 1 ? "#2a2a3e" : "#8080a0",
            padding: "4px 10px",
            borderRadius: 4,
            cursor: historyIdx === history.length - 1 ? "not-allowed" : "pointer",
            fontSize: 12,
          }}
        >
          ↪ Redo
        </button>
        <button
          onClick={reset}
          style={{
            background: "none",
            border: "1px solid #2a2a3e",
            color: "#6b6b8a",
            padding: "4px 10px",
            borderRadius: 4,
            cursor: "pointer",
            fontSize: 12,
          }}
        >
          Reset
        </button>
      </div>

      {/* Body */}
      <div style={{ display: "flex", flex: 1, overflow: "hidden", height: "calc(100vh - 53px)" }}>
        {/* Chat Panel */}
        <div
          style={{
            width: 380,
            display: "flex",
            flexDirection: "column",
            borderRight: "1px solid #1e1e32",
            background: "#0d0d1a",
          }}
        >
          {/* Messages */}
          <div
            style={{
              flex: 1,
              overflowY: "auto",
              padding: "16px",
              display: "flex",
              flexDirection: "column",
              gap: 12,
            }}
          >
            {messages.map((msg, i) => (
              <div
                key={i}
                style={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: msg.role === "user" ? "flex-end" : "flex-start",
                  gap: 4,
                }}
              >
                <div
                  style={{
                    maxWidth: "85%",
                    padding: "10px 14px",
                    borderRadius: msg.role === "user" ? "12px 12px 2px 12px" : "12px 12px 12px 2px",
                    background:
                      msg.role === "user"
                        ? "linear-gradient(135deg, #4f46e5, #7c3aed)"
                        : "#13131f",
                    border: msg.role === "user" ? "none" : "1px solid #1e1e32",
                    fontSize: 13,
                    lineHeight: 1.5,
                    color: "#e0e0f0",
                    whiteSpace: "pre-wrap",
                  }}
                >
                  {msg.content}
                </div>
                {msg.jsonSnapshot && (
                  <button
                    onClick={() => setLayoutJson(msg.jsonSnapshot)}
                    style={{
                      fontSize: 10,
                      color: "#6366f1",
                      background: "none",
                      border: "none",
                      cursor: "pointer",
                      padding: "2px 4px",
                    }}
                  >
                    ↩ restore this version
                  </button>
                )}
              </div>
            ))}
            {loading && (
              <div
                style={{
                  alignSelf: "flex-start",
                  padding: "10px 14px",
                  borderRadius: "12px 12px 12px 2px",
                  background: "#13131f",
                  border: "1px solid #1e1e32",
                  fontSize: 13,
                  color: "#6366f1",
                }}
              >
                <span style={{ animation: "pulse 1s infinite" }}>⚡ Reasoning about layout...</span>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Suggested commands */}
          <div
            style={{
              padding: "8px 16px",
              borderTop: "1px solid #1e1e32",
              display: "flex",
              flexWrap: "wrap",
              gap: 6,
            }}
          >
            {[
              "Convert to 9:16",
              "Keep product large",
              "Move headline to top",
              "Move offer badge higher",
              "Make headline smaller",
            ].map((cmd) => (
              <button
                key={cmd}
                onClick={() => setInput(cmd)}
                style={{
                  fontSize: 10,
                  padding: "4px 8px",
                  borderRadius: 4,
                  background: "#13131f",
                  border: "1px solid #1e1e32",
                  color: "#8080a0",
                  cursor: "pointer",
                  whiteSpace: "nowrap",
                }}
              >
                {cmd}
              </button>
            ))}
          </div>

          {/* Input */}
          <div
            style={{
              padding: "12px 16px",
              borderTop: "1px solid #1e1e32",
              display: "flex",
              gap: 8,
              alignItems: "flex-end",
            }}
          >
            <textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Describe a layout change..."
              rows={2}
              style={{
                flex: 1,
                background: "#13131f",
                border: "1px solid #2a2a3e",
                borderRadius: 8,
                color: "#e0e0f0",
                fontSize: 13,
                padding: "8px 12px",
                resize: "none",
                outline: "none",
                fontFamily: "inherit",
                lineHeight: 1.5,
              }}
            />
            <button
              onClick={sendMessage}
              disabled={loading || !input.trim()}
              style={{
                background:
                  loading || !input.trim()
                    ? "#1e1e32"
                    : "linear-gradient(135deg, #4f46e5, #7c3aed)",
                border: "none",
                borderRadius: 8,
                color: loading || !input.trim() ? "#3a3a5a" : "#fff",
                padding: "10px 16px",
                cursor: loading || !input.trim() ? "not-allowed" : "pointer",
                fontSize: 16,
                fontWeight: 700,
                transition: "all 0.2s",
              }}
            >
              {loading ? "..." : "→"}
            </button>
          </div>
        </div>

        {/* Right Panel */}
        <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
          {/* Tabs */}
          <div
            style={{
              display: "flex",
              borderBottom: "1px solid #1e1e32",
              background: "#0d0d1a",
              padding: "0 16px",
            }}
          >
            {["preview", "json"].map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                style={{
                  padding: "12px 20px",
                  background: "none",
                  border: "none",
                  borderBottom:
                    activeTab === tab ? "2px solid #6366f1" : "2px solid transparent",
                  color: activeTab === tab ? "#c4b5fd" : "#4a4a6a",
                  cursor: "pointer",
                  fontSize: 12,
                  fontWeight: 600,
                  letterSpacing: "0.08em",
                  textTransform: "uppercase",
                  fontFamily: "inherit",
                  transition: "all 0.15s",
                }}
              >
                {tab === "preview" ? "🖼 Preview" : "{ } JSON"}
              </button>
            ))}
          </div>

          {/* Tab Content */}
          {activeTab === "preview" ? (
            <div
              style={{
                flex: 1,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                background: "#090912",
                flexDirection: "column",
                gap: 16,
                padding: 24,
              }}
            >
              <div style={{ textAlign: "center", marginBottom: 8 }}>
                <div style={{ fontSize: 11, color: "#3a3a5a", letterSpacing: "0.1em" }}>
                  WIREFRAME PREVIEW — {artboard.width}×{artboard.height}
                </div>
              </div>
              <WireframePreview json={layoutJson} />
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "1fr 1fr 1fr",
                  gap: 8,
                  marginTop: 8,
                  width: 320,
                }}
              >
                {[
                  {
                    label: "Headline",
                    node: layoutJson.nodes["text_1778486306230_8"],
                    color: "#6366f1",
                  },
                  {
                    label: "Product",
                    node: layoutJson.nodes["img_1778489515746_17"],
                    color: "#10b981",
                  },
                  {
                    label: "Badge",
                    node: layoutJson.nodes["circle_1778488914968_15"],
                    color: "#f59e0b",
                  },
                ].map(({ label, node, color }) => (
                  <div
                    key={label}
                    style={{
                      background: "#13131f",
                      border: "1px solid #1e1e32",
                      borderRadius: 6,
                      padding: "8px",
                      fontSize: 10,
                    }}
                  >
                    <div style={{ color, marginBottom: 4, fontWeight: 700 }}>{label}</div>
                    <div style={{ color: "#4a4a6a" }}>
                      x: {Math.round(node?.x || 0)}
                    </div>
                    <div style={{ color: "#4a4a6a" }}>
                      y: {Math.round(node?.y || 0)}
                    </div>
                    <div style={{ color: "#4a4a6a" }}>
                      w: {Math.round(node?.width || 0)}
                    </div>
                    <div style={{ color: "#4a4a6a" }}>
                      h: {Math.round(node?.height || 0)}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div style={{ flex: 1, position: "relative", overflow: "hidden" }}>
              <button
                onClick={copyJson}
                style={{
                  position: "absolute",
                  top: 12,
                  right: 16,
                  zIndex: 10,
                  background: "#13131f",
                  border: "1px solid #2a2a3e",
                  color: "#8080a0",
                  padding: "4px 12px",
                  borderRadius: 4,
                  cursor: "pointer",
                  fontSize: 11,
                  fontFamily: "inherit",
                }}
              >
                Copy JSON
              </button>
              <pre
                style={{
                  margin: 0,
                  padding: "16px",
                  height: "100%",
                  overflow: "auto",
                  background: "#090912",
                  fontSize: 11,
                  lineHeight: 1.6,
                  color: "#a0a0c0",
                  fontFamily: "'DM Mono', 'Courier New', monospace",
                }}
              >
                {JSON.stringify(layoutJson, null, 2)
                  .split("\n")
                  .map((line, i) => {
                    const isKey = /"[^"]+":/.test(line) && !line.trim().startsWith('"sourceUrl"');
                    const isStr = line.includes('": "');
                    const isNum = /:\s*[-\d.]+/.test(line) && !isStr;
                    return (
                      <span key={i} style={{ display: "block" }}>
                        {isNum ? (
                          <span style={{ color: "#7dd3fc" }}>{line}</span>
                        ) : isStr ? (
                          <span style={{ color: "#86efac" }}>{line}</span>
                        ) : isKey ? (
                          <span style={{ color: "#c4b5fd" }}>{line}</span>
                        ) : (
                          <span>{line}</span>
                        )}
                      </span>
                    );
                  })}
              </pre>
            </div>
          )}
        </div>
      </div>

      <style>{`
        * { box-sizing: border-box; }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-track { background: #0d0d1a; }
        ::-webkit-scrollbar-thumb { background: #2a2a3e; border-radius: 2px; }
        @keyframes pulse { 0%,100% { opacity: 1; } 50% { opacity: 0.4; } }
      `}</style>
    </div>
  );
}
